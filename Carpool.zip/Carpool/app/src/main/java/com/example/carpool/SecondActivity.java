package com.example.carpool;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class SecondActivity extends AppCompatActivity {
    private TabLayout tabLayout;
    private ViewPager viewPager;
//    String[] tabTitles={
//            "Tab 1",
//            "Tab 2"
//    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        viewPager = (ViewPager) findViewById(R.id.viewPager);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
       viewPager.setAdapter(new ViewPagerAdapter(getSupportFragmentManager()));


        tabLayout.setupWithViewPager(viewPager);
        int[] imgResId = {
                R.drawable.menuicon,
                R.drawable.caricon
        };

        for (int i = 0; i < imgResId.length; i++) {

            tabLayout.getTabAt(i).setIcon(imgResId[i]);
        }
    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {
        private Fragment[] childFragments;

        public ViewPagerAdapter(@NonNull FragmentManager fm) {
            super(fm);
            childFragments = new Fragment[]{
                    new ChildFragment1(),
                    new ChildFragment2(),
            };
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return childFragments[position];
        }

        @Override
        public int getCount() {
            return childFragments.length;
        }
    }
}

