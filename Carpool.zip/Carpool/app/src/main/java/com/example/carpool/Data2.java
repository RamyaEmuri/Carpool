package com.example.carpool;

public class Data2 {
    String heading;
    String reason;
    String place;

    public Data2(String heading, String reason, String place){
        this.heading = heading;
        this.reason = reason;
        this.place = place;

    }
}
