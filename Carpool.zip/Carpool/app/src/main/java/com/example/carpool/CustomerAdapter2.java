package com.example.carpool;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomerAdapter2 extends RecyclerView.Adapter<CustomerAdapter2.MyViewHolder> {


    private ArrayList<Data2> dataset;
    public CustomerAdapter2(ArrayList<Data2> dataset){
        this.dataset = dataset;
    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dummy2, parent,false);
        MyViewHolder viewHolder = new MyViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

    Data2 objdata = dataset.get(position);
    holder.heading.setText(objdata.heading);
    holder.reason.setText(objdata.reason);
    holder.place.setText(objdata.place);


    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView heading;
        TextView reason;
        TextView place;

//
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

        heading = itemView.findViewById(R.id.textView8);
        reason = itemView.findViewById(R.id.textView10);
        place = itemView.findViewById(R.id.textView12);



        }
    }
}



