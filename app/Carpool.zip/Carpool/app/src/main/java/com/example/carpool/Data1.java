package com.example.carpool;

import android.service.autofill.Dataset;

public class Data1 {

    String name;
    String status;
    String time;
    String description;
    Integer image;


    public Data1(String name, String status, String time, String description, Integer image){

        this.name= name;
        this.status= status;
        this.time = time;
        this.description = description;
        this.image = image;


    }
}
