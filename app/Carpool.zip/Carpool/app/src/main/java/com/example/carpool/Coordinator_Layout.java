package com.example.carpool;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Coordinator_Layout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coordinator__layout);
    }
}
