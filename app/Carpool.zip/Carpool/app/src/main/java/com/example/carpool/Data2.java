package com.example.carpool;

public class Data2 {
    String heading;
    String reason;
    String place;
    Integer image;

    public Data2(String heading, String reason, String place, Integer image){
        this.heading = heading;
        this.reason = reason;
        this.place = place;
        this.image = image;

    }
}
