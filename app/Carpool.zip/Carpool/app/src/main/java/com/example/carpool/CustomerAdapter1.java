package com.example.carpool;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomerAdapter1 extends RecyclerView.Adapter<CustomerAdapter1.MyViewHolder> {


    private ArrayList<Data1> dataset1;
    CustomerAdapter1(ArrayList<Data1> dataset1){
        this.dataset1 = dataset1;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dummy1, parent,false);
        MyViewHolder viewHolder = new MyViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Data1 objdata1 = dataset1.get(position);
        holder.name.setText(objdata1.name);
        holder.status.setText(objdata1.status);
        holder.time.setText(objdata1.time);
        holder.description.setText(objdata1.description);
        holder.image.setImageDrawable(holder.image.getContext().getResources().getDrawable(objdata1.image));

    }

    @Override
    public int getItemCount() {
        return dataset1.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView name;
        TextView status;
        TextView time;
        TextView description;
        ImageView image;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.textView3);
            status = itemView.findViewById(R.id.textView4);
            time = itemView.findViewById(R.id.textView5);
            description = itemView.findViewById(R.id.textView6);
            image = itemView.findViewById(R.id.imageView5);
        }
    }
}
